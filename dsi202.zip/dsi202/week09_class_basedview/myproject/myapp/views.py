from django.shortcuts import render
from django.urls import reverse
from myapp.models import Customer
from django.views import View
from django.http import HttpResponse
from django.views.generic.edit import CreateView
from django.views.generic.detail import DetailView
from django.views.generic import ListView
from django.views.generic.edit import UpdateView

def home(request):
    return render(request, 'home.html')

def bike(request):
    return render(request, 'bike.html')

class Home(View):
    template_name = 'home.html'

    def get(self, request):
        return render(request,'home.html')

class Bike(View):
    template_name = 'bike.html'

    def get(self, request):
        return render(request,'bike.html')

class CustomerListView(ListView):
    model = Customer
    paginate_by = 3
    #queryset=Bike.objects.filter(type='mountain')
    template_name = 'customer_list.html'

class CustomerCreateView(CreateView):
    model = Customer
    template_name = 'customer_create.html'
    fields = ['name','dob', 'mobile']


class CustomerDetailView(DetailView):
    model = Customer
    template_name = 'customer_detail.html'

class CustomerUpdateView(UpdateView):
    model = Customer
    template_name = 'customer_update.html'
    fields = ['name', 'dob', 'mobile']
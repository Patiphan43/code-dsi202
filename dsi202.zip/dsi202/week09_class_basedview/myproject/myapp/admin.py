from django.contrib import admin
from myapp.models import Customer

admin.site.register(Customer)
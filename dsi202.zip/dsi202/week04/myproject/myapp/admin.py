from django.contrib import admin
from .models import Property, Rent, Customer
# Register your models here.

class Propertyadmin(admin.ModelAdmin):
    list_display = ('name', 'ac', 'size', 'price_per_day')
    list_editable = ['price_per_day']
class Customeradmin(admin.ModelAdmin):
    list_display = [f.name for f in Customer._meta.fields]
    list_filter = ['gender']
class Rentadmin(admin.ModelAdmin):
    list_display = [f.name for f in Rent._meta.fields]

admin.site.register(Property,Propertyadmin)
admin.site.register(Rent,Rentadmin)
admin.site.register(Customer,Customeradmin)

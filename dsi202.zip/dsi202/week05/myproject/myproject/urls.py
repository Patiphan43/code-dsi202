from django.contrib import admin
from django.urls import path
from myapp import views
from myapp.views import PropertyListView, PropertyDetailView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('home/', views.home, name='home'),
    path('', PropertyListView.as_view(), ),
    path('detail/<int:pk>/', PropertyDetailView.as_view(), name='property-detail'),
]

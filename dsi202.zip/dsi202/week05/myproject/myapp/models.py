from django.db import models
from django.urls import reverse

class Property(models.Model):
    name = models.CharField('Name',max_length=100)
    ac = models.BooleanField('AC')
    size = models.DecimalField('size',max_digits=5, decimal_places=2)
    price_per_day = models.DecimalField('price per day',max_digits=5, decimal_places=2)
    def __str__(self):
        return "{} {} {} sqm.".format(self.pk, self.name, self.size)
    def get_absolute_url(self):
        return reverse('property-detail', kwargs={'pk':self.pk})

class Customer(models.Model):
    name = models.CharField('Name',max_length=100)
    mobile = models.CharField('Mobile',max_length=20)
    dob = models.DateField('Date of birth')
    gender = models.BooleanField()
    def __str__(self):
        return (self.name)

class Rent(models.Model):
    start = models.DateTimeField('start')
    stop = models.DateTimeField('stop')
    cost = models.DecimalField('cost',max_digits=10,decimal_places=2)
    property = models.ForeignKey(Property, on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    def __str__(self):
        return "{} {}".format(self.property, self.start)

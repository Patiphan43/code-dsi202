from django import forms

from .models import Property


class PropertyModelForm(forms.ModelForm):
    class Meta:
        model = Property
        fields =[
            'name',
            'ac',
            'size',
        ]
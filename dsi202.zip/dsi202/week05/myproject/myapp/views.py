
from django.http import HttpResponse
from .models import Property

from django.shortcuts import render,get_object_or_404
from django.views.generic import ListView, DetailView


# from .forms import PropertyModelForm


def home(request):
    P=Property.objects.all()
    return render(request, 'property_list.html',{'Property':P})

class PropertyListView(ListView):
    model = Property

class PropertyDetailView(DetailView):
    model = Property
    context_object_name = 'property'
    template_name = 'templates/property_detail.html'
    # queryset = Property.objects.all()

    def get_object(self):
        id_=self.kwargs.get('pk')
        return get_object_or_404(Property,id=int(id_))


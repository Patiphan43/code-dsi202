from django.db import models

# Create your models here.
class Customer(modes.Model):
    name=